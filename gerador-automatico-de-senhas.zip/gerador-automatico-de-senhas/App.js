import React, { useState, useEffect } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';

const { width } = Dimensions.get('window');

export default function App() {
  const [contadorNormal, setContadorNormal] = useState(0);
  const [contadorPrioritario, setContadorPrioritario] = useState(0);
  const [contadorAltaPrioridade, setContadorAltaPrioridade] = useState(0);
  const [senhaGerada, setSenhaGerada] = useState('');
  const [tempoRestanteNormal, setTempoRestanteNormal] = useState(90); // 1:30 para Normal
  const [tempoRestantePrioritario, setTempoRestantePrioritario] = useState(45); // 45s para Prioritário
  const [tempoRestanteAlta, setTempoRestanteAlta] = useState(30); // 30s para Alta Prioridade
  const [proximaSenhaTipo, setProximaSenhaTipo] = useState('');

  const gerarSenhaNormal = () => {
    const novoContador = contadorNormal + 1;
    setContadorNormal(novoContador);
    setSenhaGerada(`N${novoContador.toString().padStart(2, '0')}`);
    setTempoRestanteNormal(90);
  };

  const gerarSenhaPrioritaria = () => {
    const novoContador = contadorPrioritario + 1;
    setContadorPrioritario(novoContador);
    setSenhaGerada(`P${novoContador.toString().padStart(2, '0')}`);
    setTempoRestantePrioritario(45);
  };

  const gerarSenhaAltaPrioridade = () => {
    const novoContador = contadorAltaPrioridade + 1;
    setContadorAltaPrioridade(novoContador);
    setSenhaGerada(novoContador < 10 ? `AP00${novoContador}` : `AP0${novoContador}`);
    setTempoRestanteAlta(30);
  };

  useEffect(() => {
    const timer = setInterval(() => {
      // Atualiza todos os temporizadores
      setTempoRestanteNormal(prev => prev > 0 ? prev - 1 : 0);
      setTempoRestantePrioritario(prev => prev > 0 ? prev - 1 : 0);
      setTempoRestanteAlta(prev => prev > 0 ? prev - 1 : 0);

      // Verifica qual senha deve ser gerada
      if (tempoRestanteAlta <= 0) {
        gerarSenhaAltaPrioridade();
        setProximaSenhaTipo('Normal em ' + Math.floor(tempoRestanteNormal/60) + ':' + (tempoRestanteNormal%60).toString().padStart(2, '0'));
      } else if (tempoRestantePrioritario <= 0) {
        gerarSenhaPrioritaria();
        setProximaSenhaTipo('Alta Prioridade em ' + tempoRestanteAlta + 's');
      } else if (tempoRestanteNormal <= 0) {
        gerarSenhaNormal();
        setProximaSenhaTipo('Prioritário em ' + tempoRestantePrioritario + 's');
      } else {
        // Determina qual será a próxima senha a ser gerada
        const menorTempo = Math.min(tempoRestanteNormal, tempoRestantePrioritario, tempoRestanteAlta);
        if (menorTempo === tempoRestanteAlta) {
          setProximaSenhaTipo('Alta Prioridade em ' + tempoRestanteAlta + 's');
        } else if (menorTempo === tempoRestantePrioritario) {
          setProximaSenhaTipo('Prioritário em ' + tempoRestantePrioritario + 's');
        } else {
          setProximaSenhaTipo('Normal em ' + Math.floor(tempoRestanteNormal/60) + ':' + (tempoRestanteNormal%60).toString().padStart(2, '0'));
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [tempoRestanteNormal, tempoRestantePrioritario, tempoRestanteAlta]);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Gerador Automático de Senhas</Text>
      
      <View style={styles.senhaContainer}>
        <Text style={styles.senhaText}>{senhaGerada || '--'}</Text>
        <Text style={styles.contadorText}>
          Próxima: {proximaSenhaTipo || 'Carregando...'}
        </Text>
      </View>

      <View style={styles.botoesRow}>
        <TouchableOpacity
          style={[styles.button, styles.buttonNormal]}
          onPress={gerarSenhaNormal}>
          <Text style={styles.buttonText}>Normal</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, styles.buttonPrioritario]}
          onPress={gerarSenhaPrioritaria}>
          <Text style={styles.buttonText}>Prioritário</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, styles.buttonAltaPrioridade]}
          onPress={gerarSenhaAltaPrioridade}>
          <Text style={styles.buttonText}>Alta Prioridade</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.contadoresContainer}>
        <Text style={styles.contadorItem}>Normais: {contadorNormal}</Text>
        <Text style={styles.contadorItem}>Prioritários: {contadorPrioritario}</Text>
        <Text style={styles.contadorItem}>Alta Prioridade: {contadorAltaPrioridade}</Text>
      </View>
    </View>
  );
}

// Mantenha exatamente os mesmos estilos do código anterior
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f4f7',
    padding: 20,
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 30,
    textAlign: 'center',
  },
  senhaContainer: {
    backgroundColor: '#fff',
    padding: 30,
    borderRadius: 15,
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
    alignItems: 'center',
    width: width * 0.85,
  },
  senhaText: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  contadorText: {
    fontSize: 16,
    color: '#666',
  },
  botoesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: width * 0.9,
    marginBottom: 30,
  },
  button: {
    flex: 1,
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 5,
    minHeight: 60,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  buttonNormal: {
    backgroundColor: '#4CAF50',
  },
  buttonPrioritario: {
    backgroundColor: '#FFC107',
  },
  buttonAltaPrioridade: {
    backgroundColor: '#F44336',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  contadoresContainer: {
    width: width * 0.85,
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  contadorItem: {
    fontSize: 14,
    color: '#555',
    marginVertical: 5,
  },
});